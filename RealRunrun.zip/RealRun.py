
# coding: utf-8

# In[ ]:


import random
import math
import numpy
import dill
from itertools import product
from collections import OrderedDict
from gurobipy import *
import time
from openpyxl import Workbook
from openpyxl import load_workbook
import os


fold = os.getcwd()
path = fold + "/realrundata.xlsx"
column_Name = ('Min_Cy','Sum_Cy', 'Min_Ran','Sum_Ran','Min_Obj','Sum_Obj', 'LP_Obj', 'Gap','Time')
if os.path.exists("realrundata.xlsx"):
    wb = load_workbook(filename= path)
    sheet = wb.active
else:
    wb = Workbook()
    sheet = wb.active
    sheet.append(column_Name)
    
def TakeTurn(TotalN,K,M,AdTime,AudienceNum, AudiencePreference, TotalBusTime,StopNum):
    yTurn = {}
    #計算哪個廣告開始在哪個時間段開始播
    indi_AD = 0
    indi_T = 0
    for n in range(TotalN):
        for m in range(M):
            yTurn[n,m] = 0
        if n == indi_T:
            yTurn[n,indi_AD] = 1
            indi_T = indi_T + AdTime[indi_AD]
            indi_AD = (indi_AD+1)%M
    #開始算objective
    Ad_TurnPre = {}
    for j in range(M):
        Ad_TurnPre[j] = sum( (sum(AudienceNum[w,k]*AudiencePreference[j,k] for k in range(K))*sum( yTurn[i,j] for i in range(TotalBusTime[w], TotalBusTime[w+1]) ))for w in range(StopNum) )
    Cal1 = list(Ad_TurnPre.values())
    return Ad_TurnPre[min(Ad_TurnPre, key = Ad_TurnPre.get)], numpy.sum(Cal1)

def RandomTurn(TotalN,K,M,AdTime,AudienceNum, AudiencePreference, TotalBusTime,StopNum, seed):
    random.seed(seed)
    yRan = {}
    indi_AD = 0
    indi_T = 0
    for n in range(TotalN):
        for m in range(M):
            yRan[n,m] = 0
        if n == indi_T:
            yRan[n,indi_AD] = 1
            indi_T = indi_T + AdTime[indi_AD]
            indi_AD = random.randint(0,M-1)
    Ad_RanPre = {}
    for j in range(M):
        Ad_RanPre[j] = sum( (sum(AudienceNum[w,k]*AudiencePreference[j,k] for k in range(K))*sum( yRan[i,j] for i in range(TotalBusTime[w], TotalBusTime[w+1]) ))for w in range(StopNum) )
    Cal2 = list(Ad_RanPre.values())
    return Ad_RanPre[min(Ad_RanPre, key = Ad_RanPre.get)], numpy.sum(Cal2)

def mycallback(model, where):
    if where == GRB.Callback.MIPNODE:
        if model._flag:
            model._lpobj = model.cbGet(GRB.Callback.MIPNODE_OBJBND)
            model._flag=False
    elif where == GRB.Callback.MIP:
        obj = model.cbGet(GRB.Callback.MIP_OBJBND)
        time = model.cbGet(GRB.Callback.RUNTIME)
        if time > 1800.0:
            if abs(objbst-objbnd) < 0.04 * (1.0 + abs(objbst)):
                print("Gap set to 4%")
                model.terminate()                
        elif time > 1500.0:
            if abs(objbst-objbnd) < 0.03 * (1.0 + abs(objbst)):
                print("Gap set to 3%")
                model.terminate()
        elif time > 1200.0:
            if abs(objbst-objbnd) < 0.02 * (1.0 + abs(objbst)):
                print("Gap set to 2%")
                model.terminate()
        elif time > 900.0:
            if abs(objbst-objbnd) < 0.015 * (1.0+ abs(objbst)):
                print("Gap set to 1%")
                model.terminate()
        elif time > 600.0:
            if abs(objbst-objbnd) < 0.01 * (1.0+ abs(objbst)):
                print("Gap set to 1%")
                model.terminate()

def OurAlgorithm(StopNum, K,N,M, TotalN, AdTime,AudienceNum, AudiencePreference,TotalBusTime, Conflict):
    m = Model("project")
    #Parameters
    Container = 10000
    TickSize = 10
    Safety = 0
    AdRepeatTime = 10
    AdRepeatNum = 10
    AdContinousNum = 3
    ConflictNum = 5
    RepeatTime = {}
    for j in range(M):
        RepeatTime[j] = AdTime[j]*AdRepeatTime
    #Create variables
    #ans:  最大化廣告商的最低hit數
    ans=m.addVar(lb=0,vtype=GRB.CONTINUOUS,name='ans')
    x={} #xij: 第i個時間段中是否有在播放第j種廣告( 1:播放    0:沒有播放)
    for i in range(TotalN):
        for j in range(M):
            x[i,j] = m.addVar(vtype=GRB.BINARY, name='x_%d_%d'%(i,j))
    y={} #yij:第i個時間段時第j種廣告開始播放( 1:播放    0:沒有播放)
    for i in range(TotalN):
        for j in range(M):
            y[i,j] = m.addVar(vtype=GRB.BINARY, name='y_%d_%d'%(i,j))
    c={} #cij1j2: 處理衝突限制式
    for j1 in range(M):
        j2 = j1+1
        while j2<M:
            for i in range(TotalN-ConflictNum):
                c[i,j1,j2] = m.addVar(vtype=GRB.BINARY, name='c_%d_%d_%d'%(i,j1,j2))
            j2 = j2+1
    t={}
    for j in range(M):
        t[j] = m.addVar(name='t_%d'%j)
    # Integrate new variables    
    m.update()
    #Constraints
    m.setObjective( ans , GRB.MAXIMIZE ) # Set objective 最大化廣告每日的最低hit數
    # 定義yij範圍
    for j in range(M):
        for i in range(TotalN):
            m.addConstr( y[i,j] <= x[i,j] )
            m.addConstr( quicksum( y[max(i-i0,0),j] for i0 in range(AdTime[j]) ) >= x[i,j] )
            for i1 in range(AdTime[j]):
                if i+i1<TotalN: 
                    m.addConstr( y[i,j] <= x[i+i1,j] )
                    if i1 >= 1:
                        m.addConstr( y[i,j] + y[i+i1,j] <= 1)

    #每個時間段只會播一種廣告
    for i in range(TotalN):
         m.addConstr( quicksum(x[i,j] for j in range(M)) <= 1 )

    #廣告總長度不超過上限 
    m.addConstr( quicksum(quicksum(x[i,j] for j in range(M)) for i in range(TotalN) ) * TickSize <= TickSize*TotalN-Safety )

    #在AdRepeatTime個時間段內最多播AdrepeatNum次
    for j in range(M):
        for i1 in range(TotalN-AdRepeatTime):
            m.addConstr( quicksum( y[i2,j] for i2 in range(i1,i1+AdRepeatTime) ) <= AdRepeatNum )

    #第j1和第j2個廣告可同路線ConflictNum次內播放
    for j1 in range(M):
        j2 = j1+1
        while j2<M:
            for i1 in range(TotalN-ConflictNum):
                m.addConstr( quicksum( y[i1,j1] for i1 in range(i1,ConflictNum) ) <= 10*TotalN*(Conflict[j1,j2] + 1-c[i1,j1,j2]) )
                m.addConstr( quicksum( y[i1,j2] for i1 in range(i1,ConflictNum) ) <= 10*TotalN*(Conflict[j1,j2] + 1-c[i1,j1,j2]) )
            j2 = j2+1    

    #AdContinousNum: 不可連續撥放AdContinousNum次
    for j in range(M):
        for i1 in range( TotalN-AdTime[j]*(AdContinousNum-1) ):
            m.addConstr( quicksum( y[i1+i2*AdTime[j],j] for i2 in range(AdContinousNum) ) <= AdContinousNum-1 )
    hit = {}
    #ans: 所有廣告中最低的廣告hit數
    for j in range(M):
        m.addConstr( quicksum( ((quicksum( AudienceNum[w,k]*AudiencePreference[j,k] for k in range(K)))* (quicksum( y[i,j] for i in range(TotalBusTime[w],TotalBusTime[w+1]) ) ) )for w in range(StopNum) ) >= ans )
        hit[j] = quicksum( ((quicksum( AudienceNum[w,k]*AudiencePreference[j,k] for k in range(K)))* (quicksum( y[i,j] for i in range(TotalBusTime[w],TotalBusTime[w+1]) ) ) )for w in range(StopNum) )
    for j in range(M):
        m.addConstr( quicksum( ((quicksum( AudienceNum[w,k]*AudiencePreference[j,k] for k in range(K)))* (quicksum( y[i,j] for i in range(TotalBusTime[w],TotalBusTime[w+1]) ) ) )for w in range(StopNum) ) ==t[j] )    
    
    m.setParam("TimeLimit", 2400)
    m.setParam("MIPGap", 0.005)
    
    tstart = time.time()
    m._flag = True
    m.optimize(mycallback)
    tend = time.time()
    tpass = tend-tstart
    Cal3 = []
    for i in range(M):
        Cal3.append(t[i].X)
    return m._lpobj, m.objVal, numpy.sum(Cal3), m.MIPGap, tpass

def DataLoader(caseNum):
    file = open('data','rb')
    data = dill.load(file)
    timeResult = data[caseNum][12]
    #StopNum：站數
    StopNum = len(timeResult)
    #Nw：第w站所花時間段數量，maxN：各站時間段總數
    N = {}
    temp = 0
    TotalN = 0
    TickSize=10
    TotalBusTime = {}
    TotalBusTime[0] = 0
    for w in range(StopNum-1):
        N[w] = math.ceil((timeResult[w+1]-timeResult[w]-temp)/TickSize)
        TotalN = TotalN + N[w]
        TotalBusTime[w+1] = TotalN
        temp = TotalBusTime[w+1]*TickSize-timeResult[w+1]
    N[StopNum-1] = 0
    TotalN = TotalN + N[StopNum-1]
    TotalBusTime[StopNum] = TotalN

    at = load_workbook('adtime.xlsx')
    #AdTime j: 第j種廣告時長會佔據多少時間段
    AdTime = {}
    AdName = {}
    for j in range(at['1'].max_row-1):
        AdTime[j] = at['1']['B'][j+1].value
        AdName[at['1']['A'][j+1].value] = j
    #M：廣告數量
    M = at['1'].max_row-1
    #AdRepeatTime, AdRepeatNum: 最短P個時間段內不可播放同樣廣告超過K次
    AdRepeatTime = 10
    AdRepeatNum = 10
    #AdContinousNum: 不可連續撥放AdContinousNum次
    AdContinousNum = 5

    #Conflict j1j2, ConflictNum: 第j1和第j2個廣告可同路線ConflictNum次內播放(1:可    0:不可)
    Conflict = {}
    for j1 in range(M):
        for j2 in range(M):
            Conflict[j1,j2] = 1
    cft = load_workbook('conflict.xlsx')
    for i in range(cft['1'].max_row):
        j1 = AdName.get(cft["1"]["A"][i].value)
        j2 = AdName.get(cft["1"]["B"][i].value)
        Conflict[j1,j2] = 0
        Conflict[j2,j1] = 0

    ConflictNum = 5
    #AudiencePreference jk: 客群k喜歡廣告j的程度 
    AudiencePreference = {}
    pre = load_workbook('preference.xlsx')
    for j in range(M):
        temp = 0
        for k in pre['1'][j+2]:
            if temp == 0:
                j1 = AdName.get(k.value)
                temp = temp+1
            else:
                AudiencePreference[j1,temp-1] = k.value 
                temp = temp+1
    #K: 客群種類數
    K = temp-1
    passengerResults = {}
    for i in range(12):
        passengerResults[i] = data[caseNum][i]
    #AudienceNum w,k: w時段車上有幾位屬於客群k的人
    AudienceNum = {}
    for k in range(K):
        for w in range(StopNum):
            AudienceNum[w,k] = data[caseNum][k][w]
        
    for i in range(M):
        AdTime[i] = int(AdTime[i]/TickSize)
    #呼叫三種算法
    Take_Obj, Take_Sum = TakeTurn(TotalN,K,M,AdTime,AudienceNum, AudiencePreference, TotalBusTime,StopNum)
    Rand_Obj, Rand_Sum = RandomTurn(TotalN,K,M,AdTime,AudienceNum, AudiencePreference, TotalBusTime,StopNum, caseNum)
    LP_Obj, Our_Obj, Our_Sum_Obj, mipGap, Time= OurAlgorithm(StopNum, K,N,M, TotalN, AdTime,AudienceNum, AudiencePreference,TotalBusTime,Conflict)
    ans = (Take_Obj, Take_Sum, Rand_Obj, Rand_Sum, Our_Obj, Our_Sum_Obj, LP_Obj, mipGap, Time)
    return ans
    

for i in range(0,2): #改這邊的range，上限99
    data = DataLoader(i)
    sheet.append(data)
    wb.save(path)

